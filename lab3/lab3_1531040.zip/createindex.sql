CREATE INDEX SearchForConferenceReviews
    ON Reviews(year,conferenceName);