INSERT INTO Reviews
VALUES(3489,Santa Cruz Law Review,2021,2,2021-06-30,5);

INSERT INTO Reviews
VALUES(3488,Santa Cruz Law Review,2021,71,2021-06-30,7);

INSERT INTO Authors
VALUES（22,Harvard Law Review,2020,10,-1);

INSERT INTO Authors
VALUES（22,Harvard Law Review,2020,10,3);

INSERT INTO Conferences
VALUES(Harvard Law Review,2021,2021-07-21,220.99,310.00,2020-12-10,2021-03-21,H);

INSERT INTO Conferences
VALUES(Harvard Law Review,2021,2021-07-21,220.99,110.00,2020-12-10,2021-03-21,H);

INSERT INTO Submissions
VALUES(arvard Law Review,2021,10,10,2019-12-09,NULL,'Jury Bias Analysis: Modern approaches',2020-01-31,2020-03-21);

INSERT INTO Submissions
VALUES(arvard Law Review,2021,10,10,2019-12-09,TRUE,'Jury Bias Analysis: Modern approaches',2020-01-31,2020-03-21);